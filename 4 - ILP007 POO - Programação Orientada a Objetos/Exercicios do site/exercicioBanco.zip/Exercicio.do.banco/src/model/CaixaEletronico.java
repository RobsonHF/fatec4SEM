package model;

public class CaixaEletronico {

	Conta conta = new Conta();
	
	public Conta autentica(String numero, String senha) {
		if (numero.equals(conta.getNumero())) {
			if (senha.equals(conta.getSenha())) {
				System.out.println("Conta v�lida!");
			}
		} else {
			System.out.println("Conta inv�lida!");
		}
		return conta;
	}
}
