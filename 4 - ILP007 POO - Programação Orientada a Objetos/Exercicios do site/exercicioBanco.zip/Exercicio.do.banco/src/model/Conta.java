package model;

import java.util.Date;
import java.util.List;

public class Conta {
	private Double saldo;
	private String numero;
	private String senha;
	private List<Transacao> historico;

	public Double getSaldo() {
		return saldo;
	}

	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public List<Transacao> getHistorico() {
		return historico;
	}

	public void setHistorico(List<Transacao> historico) {
		this.historico = historico;
	}

	public boolean efetuarSaque(Double valor) {
		if (this.getSaldo() > valor) {
			this.setSaldo(this.getSaldo() - valor);
			return true;
		} else {
			return false;
		}
	}

	public boolean efetuarDeposito(Double valor) {
		this.setSaldo(this.getSaldo()+valor);
		return true;
	}

	public boolean efetuarPagamento(String boleto, Double valor) {
		if (this.getSaldo() > valor) {
			this.setSaldo(this.getSaldo() - valor);
			boleto = "Boleto pago";
			return true;
		} else {
			boleto = "Saldo insuficiente";
			return false;
		}
	}

	public List<Transacao> extrato(Date inicio, Date fim) {	
		return historico;
	}
}
