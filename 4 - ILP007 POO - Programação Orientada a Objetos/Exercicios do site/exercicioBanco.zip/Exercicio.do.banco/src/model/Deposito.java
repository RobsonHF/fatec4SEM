package model;

import java.util.Date;

public class Deposito extends Transacao{
	@Override
	public Double getValor() {
		// TODO Auto-generated method stub
		return super.getValor();
	}
	@Override
	public Date getData() {
		// TODO Auto-generated method stub
		return super.getData();
	}
}
