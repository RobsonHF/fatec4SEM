package model;

public class Pagamento extends Transacao {

}
