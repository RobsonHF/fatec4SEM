package model;

public class Saque extends Transacao {

}
