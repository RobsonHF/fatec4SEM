package edu.fatec;

public interface Observer {
	
	public void update( int[] v );

}
